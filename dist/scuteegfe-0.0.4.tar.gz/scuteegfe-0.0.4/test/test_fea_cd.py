import numpy as np
from scuteegfe.mne_features_wrapper.feature_wrapper import Feature
import matplotlib.pyplot as plt
import seaborn as sns
# rng = np.random.RandomState(42)
# n_epochs, n_channels, n_times = 2, 2,250
# X = rng.randn(n_epochs, n_channels, n_times)
# feat1=Feature(X,sfreq=250,selected_funcs={'decorr_time'})
# print(feat1.features.shape)
# # feat2=Feature(X,sfreq=250,selected_funcs={'pow_freq_bands'})juju
# # print(feat2.features.shape)
# selec_fun=['pow_freq_bands']
# select_para=dict({'pow_freq_bands__freq_bands': [[2, 3.8], [4, 7], [8, 13], [14, 30], [31, 48]],
#                   'pow_freq_bands__normalize': True,
#                   'pow_freq_bands__ratios':'only',
#                   'pow_freq_bands__ratios_triu':True,
#                   'pow_freq_bands__psd_method':'fft',
#                   'pow_freq_bands__log':True})
# feat=Feature(X,sfreq=250,selected_funcs=selec_fun,funcs_params=select_para)
# print(feat.features.shape)
# print(feat.feature_names)

# mode = 'eeg_rhythm', low_fq_range = None, low_fq_width = 2., high_fq_range = 'auto',
# high_fq_width = 'auto',

rng = np.random.RandomState(42)
n_epochs, n_channels, n_times = 2, 2,250
X = rng.randn(n_epochs, n_channels, n_times)
select_para=dict({'cross_frequency_coupling__mode': 'Fixed_width',
                  'cross_frequency_coupling__low_fq_range': np.arange(4,20,2),
                  'cross_frequency_coupling__high_fq_range': np.arange(4,20,2),
                  'cross_frequency_coupling__high_fq_width': 2   })
feat=Feature(X,sfreq=250,selected_funcs={'cross_frequency_coupling'},funcs_params=select_para)
print(feat.features.shape)
print(feat.features[0,0,:])
sns.heatmap(feat.features[0,0,:].reshape((8,8)))
plt.show()
# plt.contourf(np.arange(0,7),np.arange(0,7),feat.features[0,0,:].reshape(7,7), cmap=plt.cm.Spectral_r)