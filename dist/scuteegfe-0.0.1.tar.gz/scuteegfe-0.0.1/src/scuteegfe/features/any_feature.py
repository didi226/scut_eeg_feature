import numpy as np


def compute_test1(data):
    return np.mean(data, axis=-1)


def compute_test2(data):
    return np.mean(data, axis=-1)
