# 构建
```bash
python -m build
```

# 安装
```bash
pip install --editable .
```
注：`--editable`表示以开发模式安装，对源码的改动不用重新构建和安装也能生效。
